const Employee = require('./../models/employee');
const vschema = require('./validate');
exports.getdefault = function(req, res){
  res.send('You are on the root route.');
};
exports.getemployees = function(req, res){
  Employee.find({}, function(err, results){
    if (err)
      res.end(err);
    res.json(results);
  });
};
exports.addnewemployee = function(req, res){
  const {error} = vschema.validate(req.body);
  if(error)
    return res.status(400).json({error:error.details[0].message});
  const Emp = new Employee();
  Emp.empName = req.body.empName;
  Emp.empPass = req.body.empPass;
  Emp.save({}, function(err){
    if (err)
     res.end(err);
    res.end(`Created ${Emp.empName}`);
  });
};
//
exports.addnewweight = function(req, res){
  let empName = req.body.empName;
  let empWeight = parseInt(req.body.empWeight);
  Employee.updateOne(
    {empName: empName},
    {$addToSet:
      { employeeWeights :
        {
          empWeight:empWeight
        }
      }
    },
    {upsert : true },
    function(err, doc) {
      if(err) {
        return console.log(err);
      } else {
        return res.send("done");
      }
    }
  );
};
