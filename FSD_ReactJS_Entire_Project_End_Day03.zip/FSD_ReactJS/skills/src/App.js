import React from 'react';
import Home from './components/home';
import Teamweights from './components/teamweights';
import {BrowserRouter, Route} from 'react-router-dom';

function App() {
  return (
    <div>
      <BrowserRouter>
        <Route exact path="/" component={Home}/>
        <Route path="/teamweights" component={Teamweights}/>
      </BrowserRouter>
    </div>
  );
}

export default App;
