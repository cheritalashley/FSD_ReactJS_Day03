import React, { Component } from "react";

class TwMain extends Component{
  constructor(props){
    super(props);
    this.state = {
      allWeights: []
    }
  }

  componentDidMount(){
    //this.allWeights = fetch("http://localhost:8000/getemployees");
    fetch("http://localhost:8000/getemployees")
    .then(response => response.json())
    .then(response => {
      this.setState({
        allWeights:response
      })
    })
  }

  render(){
    return (
      <main>
        <h2>All Weights</h2>
        {
          this.state.allWeights.map((emp, i) =>
            (<div key={i}>
              {emp.empName}
              {emp.employeeWeights.map((weight,j) => {
                return <div key={j}  class="indentWeights">
                  Date: {new Date(weight.weighedOn).toLocaleDateString()}
                  {' '}
                  Weight: {weight.empWeight }
                </div>
              })}
              </div>)
          )
        }
      </main>
    )
  }

}

export default TwMain
