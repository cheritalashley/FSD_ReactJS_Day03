import React from "react";
import TwContainer from "./twcontainer";
import Footer from "./footer";
import Header from "./header";

function Teamweights(){
  return (
    <div>
      <Header />
      <TwContainer />
      <Footer />
    </div>
  )
}

export default Teamweights
