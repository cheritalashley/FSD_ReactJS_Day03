import React from "react";
import TwContainer from "./twcontainer";
import Footer from "./footer";
import Header from "./header";

function Home(){
  return (
    <div>
      <Header />
      <TwContainer />
      <Footer />
    </div>
  )
}

export default Home
