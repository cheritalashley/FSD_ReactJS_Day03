import React from "react";
import TwMain from "./twmain";
import Aside from "./aside";
//
function TwContainer(){
  return (
    <div>
      <TwMain />
      <Aside />
    </div>

  )
}
//
export default TwContainer
