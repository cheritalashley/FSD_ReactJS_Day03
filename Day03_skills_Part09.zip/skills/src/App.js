import React from 'react';
import './styles.css';
import {BrowserRouter, Route} from 'react-router-dom';
import Home from './components/home';
import Teamweights from './components/teamweights';

function App() {
  return (
    <div>
      <BrowserRouter>
        <Route exact path="/home" component={Home}/>
        <Route path="/teamweights" component={Teamweights}/>
      </BrowserRouter>
    </div>
  );
}

export default App;
