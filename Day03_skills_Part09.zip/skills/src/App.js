import React from 'react';
import {BrowserRouter, Route} from 'react-router-dom';
import './styles.css';
import Home from './components/home';
import Teamweights from './components/teamweights';
function App() {
  return (
    <div>
    <BrowserRouter>
    <Route exact path="/" component={Home}/>
    <Route path="/teamweights" component={Teamweights}/>
    </BrowserRouter>
    </div>
  );
}

export default App;
