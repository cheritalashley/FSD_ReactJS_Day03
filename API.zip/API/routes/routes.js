// const path = require('path');
// const DIR_DIST = path.join(__dirname, '../dist');
// const HTML_STATIC = path.join(DIR_DIST, 'index.html');
// const express = require('express');
const controller = require('../controllers/controller');
module.exports = function(app){
  //app.use(express.static(DIR_DIST));
  //
  app.route('/').get(controller.getdefault);
  app.route('/getweights').get(controller.getweights);
  app.route('/addnewemployee').post(controller.addnewemployee);
  app.route('/addnewweight').put(controller.addnewweight);
};
