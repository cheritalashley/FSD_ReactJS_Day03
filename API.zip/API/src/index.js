import React from 'react';
import ReactDOM from 'react-dom';
import Header from './components/header';
import './styles.css';
//
const Index = () => {
  return <div><h2>Welcome to Skillsoft Live Learning</h2><Header /></div>;
};
//
ReactDOM.render(<Index />, document.getElementById('root'));
