import React from 'react';
import './styles.css';
import Header from './components/header';
function App() {
  return (
    <div>
      <h3><Header /></h3>
    </div>
  );
}

export default App;
