import React from 'react';
import './styles.css';
import Header from './components/header';

function App() {
  return (
    <div>
      <Header />
    </div>
  );
}

export default App;
